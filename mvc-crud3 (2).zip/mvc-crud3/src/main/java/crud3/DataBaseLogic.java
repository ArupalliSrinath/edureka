package crud3;

import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

@Component
public class DataBaseLogic {

    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("dev");

    public void save(Movie movie) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction et = em.getTransaction();

        try {
            et.begin();
            em.persist(movie);
            et.commit();
        } finally {
            em.close();
        }
    }

    public List<Movie> getMovies() {
        EntityManager em = emf.createEntityManager();

        try {
            return em.createNativeQuery("select * from movie", Movie.class)
                     .getResultList();
        } finally {
            em.close();
        }
    }
    
    public void delete(int id) {
    	EntityManager em = emf.createEntityManager();
    	EntityTransaction et = em.getTransaction();
    	Movie movie=em.find(Movie.class,id);
    	et.begin();
    	em.remove(movie);
    	et.commit();
    	em.close();
	}
    
    public void update(Movie movie) {
    	EntityManager em = emf.createEntityManager();
    	EntityTransaction et = em.getTransaction();
    	et.begin();
    	em.merge(movie);
    	et.commit();
    	em.close();
	}
    
    public Movie getMovie(int id) {
    	EntityManager em = emf.createEntityManager();
    	 Movie m= (Movie)em.find(Movie.class,id);
    	 em.close();
    	 return m;
    }
}
