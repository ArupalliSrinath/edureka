package crud3;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import crud3.DataBaseLogic;
import crud3.Movie;

@Controller
public class MovieController {
	
	@Autowired
	DataBaseLogic dbl;

	@GetMapping("/")
	public String load() {
	    return "main.jsp";
	}

	@GetMapping("/add-movie")
	public String addMovie() {
	    return "add.jsp";
	}

	@PostMapping("/add")
	public String add(Movie movie,RedirectAttributes attributes) {
		dbl.save(movie);
		attributes.addFlashAttribute("message","Data Added");
		return "redirect:/";
	}
	
	@GetMapping("/view-movie")
	public String view(ModelMap map,RedirectAttributes attributes ) {
		List<Movie>  movies=dbl.getMovies();
		if(movies.isEmpty()) {	
			  attributes.addFlashAttribute("message","No Data Present");
			  return "redirect:/";
		}
		map.put("movies",movies);
		return "view.jsp";
	}
	
	@GetMapping("/delete")
	public String delete(@RequestParam("id") int id,RedirectAttributes attributes) {
		dbl.delete(id);
		attributes.addFlashAttribute("message","Movie Deleted");
		return "redirect:/view-movie";
	}

	@GetMapping("/edit")
	public String update(@RequestParam("id") int id,ModelMap map) {
		Movie movie=dbl.getMovie(id);
		map.put("movie", movie);
		return "edit.jsp";
	}
	
	@PostMapping("/edit-movie")
	public String UpdateMovie(Movie movie) {
		dbl.update(movie);
		return "redirect:/view-movie";
	}

}
